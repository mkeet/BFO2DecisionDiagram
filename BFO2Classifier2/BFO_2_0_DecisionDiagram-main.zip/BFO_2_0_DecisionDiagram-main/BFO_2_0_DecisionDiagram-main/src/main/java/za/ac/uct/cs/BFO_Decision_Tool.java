/*
 * Main Programme <TODO: name>
 * @author	Chiadika Emeruem, Steve Wang
 * @date July 2021
 *
 */
import za.ac.uct.cs.models.DecisionNode;
import za.ac.uct.cs.controllers.Questions;

class BFO_Decision_Tool{
	// main function
	public static void main(String [] args){
		System.out.println("Testing 1,2");
	}
}